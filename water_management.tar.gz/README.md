
# Water Management

Python 3 code for Geektrust Water Management challenge.



